#ifndef _CLAVE
#define _CLAVE
#include <sys/ipc.h>

key_t creo_clave();

#endif
