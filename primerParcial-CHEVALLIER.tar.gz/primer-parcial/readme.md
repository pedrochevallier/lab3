#Primer parcial

Correr primero main1 y luego dos veces main2, uno con argumento 1 y el otro con argumento 2.