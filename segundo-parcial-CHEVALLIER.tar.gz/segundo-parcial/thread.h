#ifndef _THREAD
#define _THREAD

void *funcionThread(void *);

#endif
