#ifndef _KEY
#define _KEY
#include <sys/ipc.h>

key_t creo_clave(int);

#endif
