#ifndef _EVENTO
#define _EVENTO
#include <global.h>

void procesar_evento_panel(int, mensaje, void *, int *);
int procesar_evento_votante(int, mensaje);

#endif
