#Segundo parcial

Correr primero main y luego main2.