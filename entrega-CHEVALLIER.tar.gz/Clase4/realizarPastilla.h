#ifndef _REALIZARPASTILLA
#define _REALIZARPASTILLA

int generarTipo();
int generarColor();

#endif
